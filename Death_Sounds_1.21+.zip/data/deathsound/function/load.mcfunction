scoreboard objectives add deathsound_deaths deathCount
scoreboard objectives add deathsound_settings dummy

execute unless score #enabled deathsound_settings matches 0.. run scoreboard players set #enabled deathsound_settings 1
execute unless score #global deathsound_settings matches 0.. run scoreboard players set #global deathsound_settings 0