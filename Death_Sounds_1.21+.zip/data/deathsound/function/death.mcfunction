execute if score #enabled deathsound_settings matches 1 if score #global deathsound_settings matches 1 run playsound minecraft:entity.wither.spawn master @a ~ ~ ~ 1 1 1

execute if score #enabled deathsound_settings matches 1 if score #global deathsound_settings matches 0 run playsound minecraft:entity.wither.spawn master @a[distance=..128] ~ ~ ~ 8 1 0

scoreboard players set @s deathsound_deaths 0