scoreboard objectives add ds_deaths deathCount
scoreboard objectives add ds_settings dummy

execute unless score #enabled ds_settings matches 0.. run scoreboard players set #enabled ds_settings 1
execute unless score #global ds_settings matches 0.. run scoreboard players set #global ds_settings 0